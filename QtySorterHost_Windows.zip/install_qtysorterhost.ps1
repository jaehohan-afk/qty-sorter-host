# Requires: jay_host_qtysorter.exe in the same folder as this script
# Usage: Right-click "Run with PowerShell" or:
#   powershell -ExecutionPolicy Bypass -File .\install_qtysorterhost.ps1

$ErrorActionPreference = "Stop"

# --- Config ---
$ExtId = "codgnpgpealocimgiaeogajpmbckedic"
$HostName = "com.jay.qtysorter"
$InstallDir = Join-Path $env:LOCALAPPDATA "QtySorterHost"
$ExeName = "jay_host_qtysorter.exe"
$ExeSrc  = Join-Path (Split-Path -Parent $MyInvocation.MyCommand.Path) $ExeName
$ExeDst  = Join-Path $InstallDir $ExeName
$ManifestPath = Join-Path $InstallDir "$HostName.json"
$RegKey = "HKCU:\Software\Google\Chrome\NativeMessagingHosts\$HostName"

# --- Create folder ---
Write-Host "Creating $InstallDir..."
New-Item -ItemType Directory -Path $InstallDir -Force | Out-Null

# --- Copy EXE ---
if (!(Test-Path $ExeSrc)) {
  throw "Missing $ExeName next to installer script. Put $ExeName in the same folder and re-run."
}
Write-Host "Copying host EXE..."
Copy-Item -Force $ExeSrc $ExeDst

# --- Write manifest JSON ---
$escapedPath = $ExeDst.Replace('\','\\')
$manifest = @"
{
  "name": "$HostName",
  "description": "Qty Sorter native host",
  "path": "$escapedPath",
  "type": "stdio",
  "allowed_origins": [
    "chrome-extension://$ExtId/"
  ]
}
"@
Write-Host "Writing manifest: $ManifestPath"
$manifest | Out-File -Encoding ascii -FilePath $ManifestPath -Force

# --- Register in HKCU ---
Write-Host "Registering host in HKCU..."
New-Item -Path "HKCU:\Software\Google\Chrome\NativeMessagingHosts" -Force | Out-Null
New-Item -Path $RegKey -Force | Out-Null
Set-ItemProperty -Path $RegKey -Name "(default)" -Value $ManifestPath

# --- Create uninstaller ---
$Uninst = @"
# Uninstall QtySorter native host
Remove-Item -Path 'HKCU:\Software\Google\Chrome\NativeMessagingHosts\$HostName' -ErrorAction SilentlyContinue
Remove-Item -LiteralPath '$ManifestPath' -Force -ErrorAction SilentlyContinue
Remove-Item -LiteralPath '$ExeDst' -Force -ErrorAction SilentlyContinue
# Remove directory if empty
Try { Remove-Item -LiteralPath '$InstallDir' -Force -ErrorAction SilentlyContinue } Catch {}
"@
$UninstPath = Join-Path $InstallDir "uninstall_qtysorterhost.ps1"
$Uninst | Out-File -Encoding ascii -FilePath $UninstPath -Force

Write-Host ""
Write-Host "✅ Installed native host."
Write-Host "EXE: $ExeDst"
Write-Host "Manifest: $ManifestPath"
Write-Host "Registry: HKCU\Software\Google\Chrome\NativeMessagingHosts\$HostName"
Write-Host "To uninstall: powershell -ExecutionPolicy Bypass -File `"$UninstPath`""
